package tarea3.pkg2;

/**
 * 
 * @author Erick Hernández
 */
public class Alumno {
   // Inicio de la lista o conocida tambien
    private Nodo inicio;
    private String nombre;
   // Constructor que inicializamos el valor de la variable.
    public void Alumno(){
        inicio = null;
    }
       public void agregarAlFinal(String valor){
        // Define un nuevo nodo y agrega el valor.
        Nodo nuevo = new Nodo(valor);
        // Consulta si la lista esta vacia.
        if (esVacia()) {
            // Inicializa la lista agregando como inicio al nuevo nodo.
            inicio = nuevo;
        // Caso contrario recorre la lista hasta llegar al ultimo nodo
        //y agrega el nuevo.
        } else{
            // Crea ua copia de la lista.
            Nodo aux = inicio;
            // Recorre la lista hasta llegar al ultimo nodo.
            while(aux.getSiguiente() != null){
                aux = aux.getSiguiente();
            }
            // Agrega el nuevo nodo al final de la lista.
            // usando el mé todo llamado setSiguiente de la clase Nodo, este crea el nuevo enlace entre el ultimo nodo y el nuevo,
            //ya que hace referencia a otro nodo.
            aux.setSiguiente(nuevo);
        }
    }
      //verifica si la lista esta vacia 
     public boolean esVacia(){
         //Si el valor de la variable inicio es null, se regresa un true, indicando que la lista esta vacía
        if (inicio == null) {
            return true;
         //Si el valor de la variable inicio no es null, se regresa un false, indicando que la lista no esta vacía
        }else{
            return false;
        }     
    }
         //Metodo que manda a pantalla el valor de todos los nodos.
     public void listar(){
        // Verifica si la lista esta vacia.
        if (!esVacia()) {
            // Crea una copia de la lista.
            Nodo aux = inicio;
            // Posicion de los elementos de la lista.
            //Se inicia en 1 porque asi inician las listas de alumnos de las escuelas
            int i = 1;
            // Recorre la lista hasta el final.
            while(aux != null){
                // Imprime en pantalla el valor del nodo.
                System.out.println(i+": "+aux.getValor());
                // Avanza al siguiente nodo.
                aux = aux.getSiguiente();
                // Incrementa el contador de la posión.
                i++;
            }
        }
    }
    
}
