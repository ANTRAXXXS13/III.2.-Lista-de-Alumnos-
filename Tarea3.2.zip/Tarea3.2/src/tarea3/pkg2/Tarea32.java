package tarea3.pkg2;
import java.util.Scanner;
/**
 *
 * @author Erick Hernández
 */
public class Tarea32 {
    public static void main(String[] args) {
        //Declaracion de variables
        Scanner s = new Scanner(System.in);
        int n =0;
        String nombre;
        //Se declara un objeto de la clase Alumno
        Alumno listaA = new Alumno();
        //Se solicita al usuario la cantidad de alumnos que estaran en la lista.
        System.out.println("¿Cuántos alumnos quieres agregar?");
        n = s.nextInt();
        // Ya que una lista es una colección de elementos(Nodos) entre los que existe una relación,
        // en este for manda el valor que se le asigara al nuevo nodo.
        for (int i = 0; i < n; i++) {
            System.out.println("Nombre del alumno: ");
            //se captura el nombre del alumno, para asignarlo a un nuevo nodo,
            //para eso se utiliza el método Agregar al final de la clase Alumno
            listaA.agregarAlFinal(nombre= s.next());
        }
        System.out.println("==================");
        System.out.println("LISTA DE ALUMNOS: ");
        System.out.println("==================");
        //Se manda a pantalla la lista de todos los alumnos que fueron  capturados
        listaA.listar();
    }
    
}
