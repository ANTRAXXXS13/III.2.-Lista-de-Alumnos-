package tarea3.pkg2;
/**
 * 
 * @author Erick Hernández
 */
public class Nodo {
     // Variable en la cual se va a guardar el valor.
    String valor;
    // Variable para enlazar los nodos.
    Nodo siguiente;
   // Constructor que inicializamos el valor de las variables.
      public Nodo(String valor){
        this.valor = valor;
        this.siguiente = null;
    }
    // Métodos getters y setters para los atributos.
    public String getValor() {
        return valor;
    }
    public void setValor(String valor) {
        this.valor = valor;
    }
    public Nodo getSiguiente() {
        return siguiente;
    }
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }  
}
